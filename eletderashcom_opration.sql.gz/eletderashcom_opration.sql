/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: eletderashcom_opration
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `address` varchar(191) DEFAULT NULL,
  `officenumber` varchar(191) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`id`, `name`, `address`, `officenumber`, `mobile`, `remark`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'DPPA','AA','121212121','12121212','1111111111111',1,NULL,'2019-11-06 14:19:46','2019-11-06 14:19:46');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distances`
--

DROP TABLE IF EXISTS `distances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `distances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `origin_id` bigint(20) NOT NULL,
  `origin_name` varchar(191) NOT NULL,
  `destination_id` bigint(20) NOT NULL,
  `destination_name` varchar(191) NOT NULL,
  `km` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `distances_origin_id_index` (`origin_id`),
  KEY `distances_destination_id_index` (`destination_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distances`
--

LOCK TABLES `distances` WRITE;
/*!40000 ALTER TABLE `distances` DISABLE KEYS */;
INSERT INTO `distances` (`id`, `origin_id`, `origin_name`, `destination_id`, `destination_name`, `km`, `status`, `created_at`, `updated_at`) VALUES (1,1,'Bale Goba',2,'Addis Abeba',357,1,'2020-02-06 03:30:24','2020-02-06 03:30:24');
/*!40000 ALTER TABLE `distances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver_truck`
--

DROP TABLE IF EXISTS `driver_truck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver_truck` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `driverid` varchar(191) NOT NULL,
  `plate` varchar(191) NOT NULL,
  `date_recived` date NOT NULL,
  `date_detach` date DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `is_attached` tinyint(1) NOT NULL DEFAULT 1,
  `is_ready` tinyint(4) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `driver_truck_driverid_foreign` (`driverid`),
  KEY `driver_truck_plate_foreign` (`plate`),
  CONSTRAINT `driver_truck_driverid_foreign` FOREIGN KEY (`driverid`) REFERENCES `drivers` (`driverid`) ON DELETE CASCADE,
  CONSTRAINT `driver_truck_plate_foreign` FOREIGN KEY (`plate`) REFERENCES `trucks` (`plate`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver_truck`
--

LOCK TABLES `driver_truck` WRITE;
/*!40000 ALTER TABLE `driver_truck` DISABLE KEYS */;
INSERT INTO `driver_truck` (`id`, `driverid`, `plate`, `date_recived`, `date_detach`, `reason`, `status`, `is_attached`, `is_ready`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'101','75309','2020-02-10',NULL,'the reason new reson added',1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','2020-02-10 16:00:47'),
(2,'102','94388','2016-02-03','2020-02-10','the reason',1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','2020-02-10 16:07:48'),
(3,'103','94386','2020-02-15','2020-02-15','min atifito new gin wediyaw',1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','2020-02-15 09:20:19'),
(4,'104','10189','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(5,'105','94797','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(6,'106','9976','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(7,'107','76240','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(8,'108','44794','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(9,'109','94358','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(10,'110','10145','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(11,'111','94745','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(12,'112','43694','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(13,'113','47585','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(14,'114','74923','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(15,'115','47594','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(16,'116','10143','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(17,'117','77218','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(18,'118','75101','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(19,'119','9968','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(20,'120','88138','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(21,'121','75103','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(22,'122','53884','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(23,'123','88148','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(24,'124','94388','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(25,'125','75102','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(26,'126','9980','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(27,'127','9978','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(28,'128','94744','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(29,'129','77461','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(30,'130','10159','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(31,'131','77462','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(32,'132','10173','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(33,'133','75105','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(34,'134','9974','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(35,'135','10148','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(36,'136','9956','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(37,'137','53887','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(38,'138','10140','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(39,'139','75240','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(40,'140','77484','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(41,'141','47593','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(42,'142','77469','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(43,'143','47589','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(44,'144','10531','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(45,'145','77290','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(46,'146','94704','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(47,'147','94448','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(48,'148','10157','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(49,'149','10126','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(50,'150','10163','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(51,'151','77217','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(52,'152','9986','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(53,'153','10134','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(54,'154','94783','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(55,'155','10167','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(56,'156','88137','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(57,'157','74922','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(58,'158','94450','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(59,'159','88150','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(60,'160','9994','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(61,'161','94389','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(62,'162','94739','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(63,'163','10541','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(64,'164','10148','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(65,'165','77468','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(66,'166','9952','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(67,'167','53886','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(68,'168','89688','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(69,'169','94739','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(70,'170','10143','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(71,'171','77217','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(72,'172','10577','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(73,'173','95413','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(74,'174','10177','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(75,'175','9978','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(76,'176','88149','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(77,'177','75102','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(78,'178','53888','0000-00-00','0000-00-00','',1,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `driver_truck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `drivers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `driverid` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT 0,
  `birthdate` date NOT NULL,
  `zone` varchar(191) DEFAULT NULL,
  `woreda` varchar(191) DEFAULT NULL,
  `kebele` varchar(191) DEFAULT NULL,
  `housenumber` varchar(191) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `hireddate` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `drivers_driverid_index` (`driverid`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
INSERT INTO `drivers` (`id`, `driverid`, `name`, `sex`, `birthdate`, `zone`, `woreda`, `kebele`, `housenumber`, `mobile`, `hireddate`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'117','FASILE YEMER',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(2,'121','G/EGZIABHIR ABRHA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(3,'120','G/ MEDHEN H/MARIam',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(4,'127','GETNET MEKURIA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(5,'133','HAILE TESFAYE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(6,'146','MESFIN FIKRU',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(7,'153','SEWBESW MUSA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(8,'152','MULUALEM TADESE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(9,'167','TESFAYE GETAHUNNE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(10,'160','TADELE KEFELY',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(11,'116','ESKENDER TEFERA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(12,'171','TIRIT ZEMENE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(13,'172','WONDU FIYATIN',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(14,'119','FITSUM HADGO',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(15,'115','EPRAME KEBEDE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(16,'102','ABEBE ALBACHW',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(17,'101','ABEBAW LEGSE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(18,'103','ABERA BEDADA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(19,'104','ABRHA ABEBE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(20,'113','ENDALE LEGSSE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(21,'106','AMBAYE TEFERA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(22,'107','ASMER WEDJENEW',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(23,'108','BEDLU TESFAYE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(24,'110','BINIYAM GAREDW',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(25,'111','BIRHANE BERHE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(26,'112','BIRHANU HABTU',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(27,'118','FEKADU EJGU',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(28,'122','G/GIORGIS WELDU',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(29,'123','G/HIWOT HAGOS',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(30,'124','GASHAW ABEGAZ',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(31,'125','GERMAYE TESFAYE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(32,'126','GETENETE ABEBE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(33,'129','GIRMA BEZABH',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(34,'130','GIRMA TADESSE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(35,'132','HAGOS ZEWDE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(36,'134','HAILU KUMSA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(37,'136','JEMALE ALI',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(38,'143','MEKONENE JEMBERY',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(39,'140','KETIELA MOGESE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(40,'141','MAMO KEBEDE ',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(41,'144','MENGESTU OURGY',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(42,'145','MENGISTU MOLA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(43,'147','METIKU YEMER',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(44,'148','MEZGEBE ASFEHA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(45,'149','MULAT DEBELE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(46,'150','MULATE GOSISA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(47,'151','MULGETA ANGSOME',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(48,'154','SHIMELIS DEMSE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(49,'155','SISAY K/MAREAM',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(50,'156','SISAY WUDNEH',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(51,'157','SISUNIYOS TESHOME',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(52,'158','SOUDE OMER',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(53,'159','T/HAYMANOTE G/S.',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(54,'161','TADESSE BEKALU',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(55,'162','TADISU NEGASH',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(56,'163','TAMRU SHIFERAW',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(57,'166','TESFAYE ABERA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(58,'168','TESFAYE KEBEDE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(59,'170','TILAHUN MELESE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(60,'173','YOHANESE H/ GEBRE.',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(61,'174','YOSEF ALEMAYHU',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(62,'175','YOSEF AYALEW',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(63,'176','ZELALEM SEBHATE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(64,'105','ADEM NEGWO',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(65,'109','BELACHEW CHIANE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(66,'114','ENDAZENEW GELETA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(67,'128','GEZEHAGN TEFERA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(68,'131','HADISH GAYM',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(69,'135','ISRAILE DELELGN',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(70,'137','JEMALE MOHAMMED',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(71,'138','JEMALE MOHAMMED ',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(72,'139','KEBEDE ADUGNA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(73,'142','MEHARI ARAYA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(74,'164','TEGEGNWORKE FEYSA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(75,'165','TEMSGENE ADEME',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(76,'169','TESHOME ABEBE',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(77,'177','ZERIHUN TEKLU',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(78,'178','ZEWEDU ALKA',1,'0000-00-00','AA','Nifas Silk ','150','1','977777777','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2019_04_26_144309_create_trucks_table',1),
(4,'2019_05_01_153410_create_vehecletypes_table',1),
(5,'2019_05_04_094633_create_drivers_table',1),
(6,'2019_05_04_131508_create_operations_table',1),
(7,'2019_05_04_151405_create_customers_table',1),
(8,'2019_05_04_152106_create_regions_table',1),
(9,'2019_05_05_080818_create_statuses_table',1),
(10,'2019_05_05_083302_create_statustypes_table',1),
(11,'2019_05_07_183529_create_performances_table',1),
(12,'2019_05_08_145526_create_driver_truck_table',1),
(13,'2019_05_09_084348_create_places_table',1),
(14,'2019_06_04_071612_create_performance_by_model_report_views',1),
(15,'2019_10_08_072533_create_permission_tables',1),
(16,'2019_10_12_151817_create_profiles_table',1),
(17,'2019_11_25_123748_create_notifications_table',1),
(18,'2019_11_30_081315_create_performance_by_driver_view',1),
(19,'2019_11_30_095017_create_performance_by_plate_view',1),
(20,'2019_11_30_111542_create_distances_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` (`permission_id`, `model_type`, `model_id`) VALUES (1,'App\\User',1),
(1,'App\\User',3),
(2,'App\\User',1),
(2,'App\\User',3),
(3,'App\\User',1),
(3,'App\\User',3),
(4,'App\\User',1),
(4,'App\\User',3),
(5,'App\\User',1),
(5,'App\\User',3),
(6,'App\\User',1),
(6,'App\\User',3),
(7,'App\\User',1),
(7,'App\\User',3),
(8,'App\\User',1),
(8,'App\\User',3),
(9,'App\\User',1),
(9,'App\\User',3),
(10,'App\\User',1),
(10,'App\\User',3),
(11,'App\\User',1),
(11,'App\\User',3),
(12,'App\\User',1),
(12,'App\\User',3),
(13,'App\\User',1),
(13,'App\\User',3),
(14,'App\\User',1),
(14,'App\\User',3),
(15,'App\\User',1),
(15,'App\\User',3),
(16,'App\\User',1),
(16,'App\\User',3),
(17,'App\\User',1),
(17,'App\\User',3),
(18,'App\\User',1),
(18,'App\\User',3),
(19,'App\\User',1),
(19,'App\\User',3),
(20,'App\\User',1),
(20,'App\\User',3),
(21,'App\\User',1),
(21,'App\\User',3),
(22,'App\\User',1),
(22,'App\\User',3),
(23,'App\\User',1),
(23,'App\\User',3),
(24,'App\\User',1),
(24,'App\\User',3),
(25,'App\\User',1),
(25,'App\\User',3),
(26,'App\\User',1),
(26,'App\\User',3),
(27,'App\\User',1),
(27,'App\\User',3),
(28,'App\\User',1),
(28,'App\\User',3),
(29,'App\\User',1),
(29,'App\\User',3),
(30,'App\\User',1),
(30,'App\\User',3),
(31,'App\\User',1),
(31,'App\\User',3),
(32,'App\\User',1),
(32,'App\\User',3),
(33,'App\\User',1),
(33,'App\\User',3),
(34,'App\\User',1),
(34,'App\\User',3),
(35,'App\\User',1),
(35,'App\\User',3),
(36,'App\\User',1),
(36,'App\\User',3),
(37,'App\\User',1),
(37,'App\\User',3),
(38,'App\\User',1),
(38,'App\\User',3),
(39,'App\\User',1),
(39,'App\\User',3),
(40,'App\\User',1),
(40,'App\\User',3),
(41,'App\\User',1),
(41,'App\\User',3),
(42,'App\\User',1),
(42,'App\\User',3),
(43,'App\\User',1),
(43,'App\\User',3),
(44,'App\\User',1),
(44,'App\\User',3),
(45,'App\\User',1),
(45,'App\\User',3),
(46,'App\\User',1),
(46,'App\\User',3),
(47,'App\\User',1),
(47,'App\\User',3);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES (1,'App\\User',1),
(2,'App\\User',3),
(3,'App\\User',4);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(191) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operations`
--

DROP TABLE IF EXISTS `operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `operationid` varchar(191) NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `startdate` datetime NOT NULL,
  `region_id` int(10) unsigned DEFAULT NULL,
  `volume` double(12,4) NOT NULL,
  `cargotype` tinyint(1) NOT NULL DEFAULT 1,
  `km` double(12,4) DEFAULT NULL,
  `tariff` double(12,4) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `closed` tinyint(1) NOT NULL DEFAULT 1,
  `enddate` date DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operations`
--

LOCK TABLES `operations` WRITE;
/*!40000 ALTER TABLE `operations` DISABLE KEYS */;
INSERT INTO `operations` (`id`, `operationid`, `customer_id`, `startdate`, `region_id`, `volume`, `cargotype`, `km`, `tariff`, `status`, `closed`, `enddate`, `remark`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'125',1,'2019-11-17 00:00:00',1,123.0000,1,1254.0000,3.2500,0,1,NULL,NULL,NULL,'2019-11-17 07:14:36','2019-12-30 18:59:00'),
(2,'1222',1,'2019-11-26 00:00:00',1,25874.0000,1,231457.0000,2.7880,1,1,NULL,NULL,NULL,'2019-11-26 03:02:14','2019-11-26 03:02:14');
/*!40000 ALTER TABLE `operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `performance_by_driver_view`
--

DROP TABLE IF EXISTS `performance_by_driver_view`;
/*!50001 DROP VIEW IF EXISTS `performance_by_driver_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `performance_by_driver_view` AS SELECT
 1 AS `id`,
  1 AS `driverid`,
  1 AS `name`,
  1 AS `plate`,
  1 AS `DateDispach`,
  1 AS `fo`,
  1 AS `CargoVolumMT`,
  1 AS `TDWC`,
  1 AS `TDWOC`,
  1 AS `tonkm`,
  1 AS `fl`,
  1 AS `fB`,
  1 AS `perdiem`,
  1 AS `workOnGoing`,
  1 AS `other` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `performance_by_model_report_views`
--

DROP TABLE IF EXISTS `performance_by_model_report_views`;
/*!50001 DROP VIEW IF EXISTS `performance_by_model_report_views`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `performance_by_model_report_views` AS SELECT
 1 AS `vehecletype_id`,
  1 AS `name`,
  1 AS `no`,
  1 AS `Trip`,
  1 AS `dwc`,
  1 AS `dwoc`,
  1 AS `Tone`,
  1 AS `KM`,
  1 AS `Tonek`,
  1 AS `fl`,
  1 AS `fib`,
  1 AS `Perdium`,
  1 AS `other`,
  1 AS `totla` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `performance_by_plate_view`
--

DROP TABLE IF EXISTS `performance_by_plate_view`;
/*!50001 DROP VIEW IF EXISTS `performance_by_plate_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `performance_by_plate_view` AS SELECT
 1 AS `id`,
  1 AS `plate`,
  1 AS `driverid`,
  1 AS `dtplate`,
  1 AS `name`,
  1 AS `DateDispach`,
  1 AS `fo`,
  1 AS `CargoVolumMT`,
  1 AS `TDWC`,
  1 AS `TDWOC`,
  1 AS `tonkm`,
  1 AS `fl`,
  1 AS `fB` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `performances`
--

DROP TABLE IF EXISTS `performances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `performances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `trip` tinyint(1) NOT NULL DEFAULT 0,
  `LoadType` tinyint(1) NOT NULL,
  `FOnumber` varchar(191) NOT NULL,
  `operation_id` int(11) NOT NULL,
  `driver_truck_id` int(11) NOT NULL,
  `DateDispach` datetime NOT NULL,
  `orgion_id` int(11) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `DistanceWCargo` double(12,4) NOT NULL,
  `tonkm` double(20,4) NOT NULL DEFAULT 0.0000,
  `DistanceWOCargo` double(12,4) DEFAULT NULL,
  `CargoVolumMT` double(12,4) DEFAULT NULL,
  `fuelInLitter` double(12,4) DEFAULT NULL,
  `fuelInBirr` double(12,4) DEFAULT NULL,
  `perdiem` double(12,4) DEFAULT NULL,
  `workOnGoing` double(12,4) DEFAULT NULL,
  `other` double(12,4) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `satus` tinyint(1) NOT NULL DEFAULT 1,
  `is_returned` tinyint(1) NOT NULL DEFAULT 0,
  `returned_date` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performances_operation_id_index` (`operation_id`),
  KEY `performances_driver_truck_id_index` (`driver_truck_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performances`
--

LOCK TABLES `performances` WRITE;
/*!40000 ALTER TABLE `performances` DISABLE KEYS */;
/*!40000 ALTER TABLE `performances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'truck create','web','2019-11-05 05:34:39','2019-11-05 05:34:39'),
(2,'truck edit','web','2019-11-05 05:34:39','2019-11-05 05:34:39'),
(3,'truck delete','web','2019-11-05 05:34:39','2019-11-05 05:34:39'),
(4,'truck view','web','2019-11-05 05:34:40','2019-11-05 05:34:40'),
(5,'truck_model create','web','2019-11-05 05:34:40','2019-11-05 05:34:40'),
(6,'truck_model edit','web','2019-11-05 05:34:40','2019-11-05 05:34:40'),
(7,'truck_model delete','web','2019-11-05 05:34:40','2019-11-05 05:34:40'),
(8,'truck_model view','web','2019-11-05 05:34:40','2019-11-05 05:34:40'),
(9,'driver create','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(10,'driver edit','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(11,'driver delete','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(12,'driver view','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(13,'operation create','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(14,'operation edit','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(15,'operation delete','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(16,'operation view','web','2019-11-05 05:34:41','2019-11-05 05:34:41'),
(17,'operation_place create','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(18,'operation_place edit','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(19,'operation_place delete','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(20,'operation_place view','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(21,'operation_region create','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(22,'operation_region edit','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(23,'operation_region delete','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(24,'operation_region view','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(25,'customer create','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(26,'customer edit','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(27,'customer delete','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(28,'customer view','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(29,'performance create','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(30,'performance edit','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(31,'performance delete','web','2019-11-05 05:34:42','2019-11-05 05:34:42'),
(32,'performance view','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(33,'status create','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(34,'status edit','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(35,'status delete','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(36,'status view','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(37,'status_type create','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(38,'status_type edit','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(39,'status_type delete','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(40,'status_type view','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(41,'truck_driver create','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(42,'truck_driver edit','web','2019-11-05 05:34:43','2019-11-05 05:34:43'),
(43,'truck_driver delete','web','2019-11-05 05:34:44','2019-11-05 05:34:44'),
(44,'truck_driver view','web','2019-11-05 05:34:44','2019-11-05 05:34:44'),
(45,'truck deactivate','web','2019-11-19 18:00:00','2019-11-19 18:00:00'),
(46,'driver deactivate','web','2019-11-19 18:00:00','2019-11-19 18:00:00'),
(47,'truck_driver detach','web','2019-11-19 18:00:00','2019-11-19 18:00:00');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `places` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `region_id` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `places_region_id_index` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `places`
--

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` (`id`, `name`, `region_id`, `comment`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Bale Goba',1,NULL,1,NULL,'2019-11-17 06:42:07','2019-11-17 06:42:07'),
(2,'Addis Abeba',1,'my second contry',1,NULL,'2019-11-17 06:49:29','2019-11-17 06:49:29');
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(191) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `about` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profiles_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` (`id`, `image`, `user_id`, `about`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'uploads/avatar.jpg',1,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-11-05 05:34:47','2019-11-05 05:34:47'),
(2,'uploads/avatar.jpg',2,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-11-17 07:21:55','2019-11-17 07:21:55'),
(3,'uploads/images/1574752602IMG_20191118_090235_9.jpg',3,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-11-25 08:24:12','2019-11-26 04:16:42'),
(4,'uploads/avatar.jpg',4,'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',NULL,'2019-11-29 10:38:26','2019-11-29 10:38:26');
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `regions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `comment` varchar(191) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` (`id`, `name`, `comment`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Cental','the central part of the countryy',1,NULL,'2019-11-06 13:35:45','2019-11-06 13:35:53');
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES (1,1),
(2,1),
(3,1),
(4,1),
(4,3),
(5,1),
(6,1),
(7,1),
(8,1),
(8,3),
(9,1),
(10,1),
(11,1),
(12,1),
(12,3),
(13,1),
(14,1),
(15,1),
(16,1),
(16,3),
(17,1),
(18,1),
(19,1),
(20,1),
(20,3),
(21,1),
(22,1),
(23,1),
(24,1),
(24,3),
(25,1),
(26,1),
(27,1),
(28,1),
(28,3),
(29,1),
(30,1),
(31,1),
(32,1),
(32,3),
(33,1),
(34,1),
(35,1),
(36,1),
(36,3),
(37,1),
(38,1),
(39,1),
(40,1),
(40,3),
(41,1),
(42,1),
(43,1),
(44,1),
(44,3),
(45,1),
(46,1),
(47,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'admin','web','2019-11-05 05:34:44','2019-11-05 05:34:44'),
(2,'user','web','2019-11-05 05:34:44','2019-11-05 05:34:44'),
(3,'Mangemnet','web','2019-11-29 10:35:25','2019-11-29 10:35:25');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuses`
--

DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `autoid` int(11) NOT NULL DEFAULT 1,
  `statustype_id` int(11) DEFAULT NULL,
  `plate` varchar(191) NOT NULL,
  `registerddate` date NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuses`
--

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` (`id`, `autoid`, `statustype_id`, `plate`, `registerddate`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,2,'75309','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(2,1,2,'94388','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(3,1,1,'94386','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(4,1,3,'10189','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(5,1,4,'94797','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(6,1,1,'9976','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(7,1,5,'76240','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(8,1,2,'44794','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(9,1,3,'94358','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(10,1,4,'10145','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(11,1,1,'94745','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(12,1,3,'43694','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(13,1,1,'47585','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(14,1,3,'74923','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(15,1,3,'47594','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(16,1,3,'10143','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(17,1,4,'77218','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(18,1,4,'75101','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(19,1,3,'9968','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(20,1,4,'88138','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(21,1,4,'75103','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(22,1,1,'53884','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(23,1,3,'88148','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(24,1,3,'94388','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(25,1,4,'75102','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(26,1,4,'9980','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(27,1,3,'9978','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(28,1,1,'94744','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(29,1,1,'77461','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(30,1,1,'10159','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(31,1,1,'77462','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(32,1,3,'10173','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(33,1,3,'75105','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(34,1,3,'9974','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(35,1,2,'10148','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(36,1,1,'9956','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(37,1,4,'53887','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(38,1,4,'10140','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(39,1,1,'75240','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(40,1,4,'77484','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(41,1,2,'47593','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(42,1,2,'77469','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(43,1,5,'47589','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(44,1,4,'10531','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(45,1,3,'77290','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(46,1,2,'94704','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(47,1,5,'94448','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(48,1,4,'10157','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(49,1,2,'10126','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(50,1,1,'10163','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(51,1,4,'77217','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(52,1,3,'9986','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(53,1,3,'10134','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(54,1,3,'94783','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(55,1,2,'10167','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(56,1,4,'88137','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(57,1,3,'74922','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(58,1,2,'94450','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(59,1,3,'88150','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(60,1,4,'9994','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(61,1,3,'94389','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(62,1,3,'94739','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(63,1,4,'10541','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(64,1,1,'10148','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(65,1,1,'77468','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(66,1,1,'9952','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(67,1,2,'53886','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(68,1,2,'89688','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(69,1,2,'94739','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(70,1,1,'10143','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(71,1,2,'77217','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(72,1,1,'10577','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(73,1,1,'95413','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(74,1,1,'10177','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(75,1,2,'9978','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(76,1,2,'88149','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(77,1,2,'75102','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(78,1,1,'53888','2020-01-01',NULL,'2019-12-31 18:00:00','2020-01-01 04:57:13'),
(79,2,2,'75309','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(80,2,3,'94388','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(81,2,4,'94386','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(82,2,3,'10189','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(83,2,2,'94797','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(84,2,2,'9976','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(85,2,2,'76240','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(86,2,1,'44794','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(87,2,1,'94358','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(88,2,2,'10145','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(89,2,3,'94745','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(90,2,2,'43694','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(91,2,2,'47585','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(92,2,3,'74923','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(93,2,4,'47594','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(94,2,3,'10143','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(95,2,3,'77218','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(96,2,4,'75101','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(97,2,3,'9968','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(98,2,5,'88138','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(99,2,1,'75103','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(100,2,4,'53884','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(101,2,1,'88148','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(102,2,1,'94388','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(103,2,2,'75102','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(104,2,2,'9980','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(105,2,1,'9978','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(106,2,1,'94744','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(107,2,1,'77461','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(108,2,1,'10159','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(109,2,1,'77462','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(110,2,3,'10173','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(111,2,2,'75105','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(112,2,1,'9974','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(113,2,1,'10148','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(114,2,1,'9956','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(115,2,1,'53887','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(116,2,1,'10140','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(117,2,1,'75240','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(118,2,1,'77484','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(119,2,1,'47593','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(120,2,1,'77469','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(121,2,1,'47589','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(122,2,1,'10531','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(123,2,1,'77290','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(124,2,1,'94704','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(125,2,1,'94448','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(126,2,1,'10157','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(127,2,1,'10126','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(128,2,1,'10163','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(129,2,1,'77217','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(130,2,1,'9986','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(131,2,1,'10134','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(132,2,1,'94783','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(133,2,1,'10167','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(134,2,1,'88137','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(135,2,1,'74922','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(136,2,1,'94450','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(137,2,1,'88150','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(138,2,1,'9994','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(139,2,1,'94389','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(140,2,1,'94739','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(141,2,1,'10541','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(142,2,1,'10148','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(143,2,1,'77468','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(144,2,1,'9952','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(145,2,1,'53886','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(146,2,1,'89688','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(147,2,1,'94739','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(148,2,1,'10143','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(149,2,1,'77217','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(150,2,1,'10577','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(151,2,2,'95413','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(152,2,4,'10177','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(153,2,2,'9978','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(154,2,4,'88149','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(155,2,1,'75102','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(156,2,1,'53888','2020-01-02',NULL,'2019-12-31 18:00:00','2020-01-01 05:00:32'),
(157,3,1,'75309','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(158,3,4,'94388','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(159,3,5,'94386','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(160,3,1,'10189','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(161,3,3,'94797','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(162,3,3,'9976','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(163,3,1,'76240','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(164,3,2,'44794','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(165,3,5,'94358','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(166,3,3,'10145','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(167,3,3,'94745','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(168,3,4,'43694','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(169,3,3,'47585','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(170,3,4,'74923','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(171,3,2,'47594','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(172,3,5,'10143','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(173,3,2,'77218','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(174,3,3,'75101','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(175,3,3,'9968','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(176,3,2,'88138','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(177,3,4,'75103','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(178,3,5,'53884','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(179,3,3,'88148','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(180,3,2,'94388','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(181,3,3,'75102','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(182,3,1,'9980','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(183,3,2,'9978','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(184,3,2,'94744','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(185,3,1,'77461','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(186,3,1,'10159','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(187,3,5,'77462','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(188,3,2,'10173','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(189,3,3,'75105','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(190,3,2,'9974','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(191,3,2,'10148','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(192,3,2,'9956','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(193,3,1,'53887','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(194,3,1,'10140','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(195,3,1,'75240','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(196,3,1,'77484','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(197,3,3,'47593','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(198,3,3,'77469','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(199,3,1,'47589','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(200,3,1,'10531','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(201,3,3,'77290','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(202,3,4,'94704','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(203,3,1,'94448','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(204,3,3,'10157','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(205,3,1,'10126','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(206,3,1,'10163','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(207,3,1,'77217','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(208,3,1,'9986','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(209,3,1,'10134','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(210,3,1,'94783','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(211,3,3,'10167','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(212,3,4,'88137','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(213,3,4,'74922','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(214,3,4,'94450','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(215,3,4,'88150','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(216,3,3,'9994','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(217,3,3,'94389','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(218,3,4,'94739','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(219,3,3,'10541','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(220,3,2,'10148','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(221,3,3,'77468','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(222,3,5,'9952','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(223,3,2,'53886','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(224,3,2,'89688','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(225,3,3,'94739','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(226,3,3,'10143','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(227,3,1,'77217','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(228,3,1,'10577','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(229,3,1,'95413','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(230,3,1,'10177','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(231,3,3,'9978','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(232,3,1,'88149','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(233,3,2,'75102','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16'),
(234,3,1,'53888','2020-02-12',NULL,'2020-02-11 21:00:00','2020-02-12 12:03:16');
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statustypes`
--

DROP TABLE IF EXISTS `statustypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `statustypes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `statusgroup` tinyint(1) NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statustypes`
--

LOCK TABLES `statustypes` WRITE;
/*!40000 ALTER TABLE `statustypes` DISABLE KEYS */;
INSERT INTO `statustypes` (`id`, `name`, `statusgroup`, `comment`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'On Road',0,'the commnet',1,NULL,'2019-11-17 08:43:41','2019-11-17 08:43:41'),
(2,'Wating Sparepert',1,'sssssssssssss',1,NULL,'2019-11-17 08:44:09','2019-11-17 08:44:09'),
(3,'On Garaje',1,'ssssssssss',1,NULL,'2019-11-25 02:27:37','2019-11-25 02:27:37'),
(4,'On Quee',0,'ss',1,NULL,'2019-11-25 02:27:54','2019-11-25 02:27:54'),
(5,'Insurance',0,'it\'s mainly the purchase dep case',1,NULL,'2019-11-25 07:52:53','2019-11-25 07:52:53');
/*!40000 ALTER TABLE `statustypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trucks`
--

DROP TABLE IF EXISTS `trucks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trucks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plate` varchar(191) NOT NULL,
  `vehecletype_id` int(10) unsigned NOT NULL,
  `chasisNumber` varchar(191) DEFAULT NULL,
  `engineNumber` varchar(191) DEFAULT NULL,
  `tyreSyze` int(11) DEFAULT NULL,
  `serviceIntervalKM` double(12,4) DEFAULT NULL,
  `purchasePrice` double(12,4) DEFAULT NULL,
  `productionDate` date DEFAULT NULL,
  `serviceStartDate` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trucks_plate_index` (`plate`),
  KEY `trucks_vehecletype_id_index` (`vehecletype_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trucks`
--

LOCK TABLES `trucks` WRITE;
/*!40000 ALTER TABLE `trucks` DISABLE KEYS */;
INSERT INTO `trucks` (`id`, `plate`, `vehecletype_id`, `chasisNumber`, `engineNumber`, `tyreSyze`, `serviceIntervalKM`, `purchasePrice`, `productionDate`, `serviceStartDate`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'75309',3,NULL,NULL,16,10000.0000,8.0000,'1967-03-01','1967-03-01',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','2020-02-01 09:07:46'),
(2,'94388',2,NULL,NULL,16,10000.0000,8.0000,'2011-03-01','2011-04-01',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','2020-02-04 10:42:30'),
(3,'94386',2,NULL,NULL,16,10000.0000,8.0000,'1999-12-12','1999-12-12',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','2020-02-04 10:48:30'),
(4,'10189',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(5,'94797',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(6,'9976',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(7,'76240',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(8,'44794',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(9,'94358',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(10,'10145',1,NULL,NULL,16,10000.0000,8.0000,'2013-11-30','2013-11-30',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','2020-02-12 11:10:20'),
(11,'94745',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(12,'43694',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(13,'47585',2,'','',18,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(14,'74923',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(15,'47594',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(16,'10143',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(17,'77218',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(18,'75101',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(19,'9968',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(20,'88138',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(21,'75103',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(22,'53884',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(23,'88148',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(24,'94388',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(25,'75102',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(26,'9980',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(27,'9978',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(28,'94744',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(29,'77461',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(30,'10159',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(31,'77462',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(32,'10173',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(33,'75105',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(34,'9974',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(35,'10148',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(36,'9956',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(37,'53887',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(38,'10140',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(39,'75240',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(40,'77484',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(41,'47593',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(42,'77469',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(43,'47589',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(44,'10531',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(45,'77290',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(46,'94704',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(47,'94448',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(48,'10157',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(49,'10126',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(50,'10163',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(51,'77217',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(52,'9986',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(53,'10134',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(54,'94783',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(55,'10167',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(56,'88137',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(57,'74922',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(58,'94450',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(59,'88150',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(60,'9994',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(61,'94389',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(62,'94739',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(63,'10541',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(64,'10148',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(65,'77468',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(66,'9952',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(67,'53886',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(68,'89688',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(69,'94739',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(70,'10143',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(71,'77217',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(72,'10577',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(73,'95413',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(74,'10177',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(75,'9978',1,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(76,'88149',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(77,'75102',3,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(78,'53888',2,'','',16,10000.0000,8.0000,'0000-00-00','0000-00-00',1,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `trucks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `active`, `admin`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'Yetimesht Tadesse','yetimnew@gmail.com',NULL,'$2y$10$WCRgCOZZ2LrwVjNW8q/nGOw5132ncjbg2TMNRY4FQ4N/UL.qz5PM.',1,1,'nW8NSLs3BVyHuEg3nCLrpX2N7kMHFwo69Gh9FvsGBg00iaBzPVc7D9EPpUuy','2019-11-05 05:34:44','2019-11-05 05:34:44'),
(3,'Beza Sikur','beza@gmail.com',NULL,'$2y$10$IYApLUvafIVi5OhcLMO3Au3IrjQ3w0J9eDuc67DebQC1.zRd0e32a',0,0,'18WJziLTToy8lworCgzh7wR3EADuYUGTrGUkVx1jPAImQSKiWphBaDX4Nx3K','2019-11-25 08:23:55','2019-11-26 04:16:42'),
(4,'Aregawi Haylu','aregaw@gmail.com',NULL,'$2y$10$LQY24ohY0Nlf.qTQ1pN9guU.WyRPwAUQkXtlvI5uE.6BKXYVuBXeS',0,0,NULL,'2019-11-29 10:38:26','2019-11-29 10:38:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehecletypes`
--

DROP TABLE IF EXISTS `vehecletypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehecletypes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `company` varchar(191) DEFAULT NULL,
  `productiondate` varchar(191) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehecletypes`
--

LOCK TABLES `vehecletypes` WRITE;
/*!40000 ALTER TABLE `vehecletypes` DISABLE KEYS */;
INSERT INTO `vehecletypes` (`id`, `name`, `company`, `productiondate`, `comment`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Old','old comopany producer','2019-11-06','64h4',1,NULL,'2019-11-06 13:18:56','2019-11-06 13:18:56'),
(2,'Truker','Trucker','2006-07-26','the date is fake date',1,NULL,'2019-11-26 03:11:24','2019-11-26 03:11:24'),
(3,'Renolt','Renolt','2019-11-26',NULL,1,NULL,'2019-11-26 03:11:48','2019-11-26 03:11:48');
/*!40000 ALTER TABLE `vehecletypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'eletderashcom_opration'
--

--
-- Dumping routines for database 'eletderashcom_opration'
--

--
-- Final view structure for view `performance_by_driver_view`
--

/*!50001 DROP VIEW IF EXISTS `performance_by_driver_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`eletderashcom`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `performance_by_driver_view` AS (select `driver_truck`.`id` AS `id`,`driver_truck`.`driverid` AS `driverid`,`drivers`.`name` AS `name`,`driver_truck`.`plate` AS `plate`,`performances`.`DateDispach` AS `DateDispach`,sum(`performances`.`trip`) AS `fo`,sum(`performances`.`CargoVolumMT`) AS `CargoVolumMT`,sum(`performances`.`DistanceWCargo`) AS `TDWC`,sum(`performances`.`DistanceWOCargo`) AS `TDWOC`,sum(`performances`.`tonkm`) AS `tonkm`,sum(`performances`.`fuelInLitter`) AS `fl`,sum(`performances`.`fuelInBirr`) AS `fB`,sum(`performances`.`perdiem`) AS `perdiem`,sum(`performances`.`workOnGoing`) AS `workOnGoing`,sum(`performances`.`other`) AS `other` from ((`performances` left join `driver_truck` on(`driver_truck`.`id` = `performances`.`driver_truck_id`)) left join `drivers` on(`drivers`.`driverid` = `driver_truck`.`driverid`)) group by `driver_truck`.`id` order by count(`performances`.`FOnumber`) desc) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `performance_by_model_report_views`
--

/*!50001 DROP VIEW IF EXISTS `performance_by_model_report_views`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`eletderashcom`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `performance_by_model_report_views` AS (select `trucks`.`vehecletype_id` AS `vehecletype_id`,`vehecletypes`.`name` AS `name`,count(distinct `trucks`.`plate`) AS `no`,sum(`performances`.`trip`) AS `Trip`,sum(`performances`.`DistanceWCargo`) AS `dwc`,sum(`performances`.`DistanceWOCargo`) AS `dwoc`,sum(`performances`.`CargoVolumMT`) AS `Tone`,sum(`performances`.`DistanceWCargo`) + sum(`performances`.`DistanceWOCargo`) AS `KM`,sum(`performances`.`CargoVolumMT` * `performances`.`DistanceWCargo`) AS `Tonek`,sum(`performances`.`fuelInLitter`) AS `fl`,sum(`performances`.`fuelInBirr`) AS `fib`,sum(`performances`.`perdiem`) AS `Perdium`,sum(`performances`.`other`) AS `other`,sum(`performances`.`fuelInBirr`) + sum(`performances`.`perdiem`) + sum(`performances`.`other`) AS `totla` from ((`trucks` join `vehecletypes` on(`vehecletypes`.`id` = `trucks`.`vehecletype_id`)) left join `performances` on(`trucks`.`id` = `performances`.`driver_truck_id`)) group by `vehecletypes`.`id` order by `performances`.`FOnumber` desc) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `performance_by_plate_view`
--

/*!50001 DROP VIEW IF EXISTS `performance_by_plate_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`eletderashcom`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `performance_by_plate_view` AS (select `trucks`.`id` AS `id`,`trucks`.`plate` AS `plate`,`driver_truck`.`driverid` AS `driverid`,`driver_truck`.`plate` AS `dtplate`,`drivers`.`name` AS `name`,`performances`.`DateDispach` AS `DateDispach`,count(`performances`.`FOnumber`) AS `fo`,sum(`performances`.`CargoVolumMT`) AS `CargoVolumMT`,sum(`performances`.`DistanceWCargo`) AS `TDWC`,sum(`performances`.`DistanceWOCargo`) AS `TDWOC`,sum(`performances`.`tonkm`) AS `tonkm`,sum(`performances`.`fuelInLitter`) AS `fl`,sum(`performances`.`fuelInBirr`) AS `fB` from (((`performances` left join `driver_truck` on(`driver_truck`.`id` = `performances`.`driver_truck_id`)) left join `drivers` on(`drivers`.`driverid` = `driver_truck`.`driverid`)) left join `trucks` on(`trucks`.`id` = `performances`.`driver_truck_id`)) group by `trucks`.`plate` order by sum(`performances`.`tonkm`) desc) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-28  7:11:44
